"""Theme typography contracts shared by SVG conversion and PPTX assembly."""

from __future__ import annotations

import math
import re
import statistics
from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree as ET

from language_tags import language_base, language_uses_rtl

from .utils import _explicit_language_script, font_px_to_hpt, parse_font_family


DML_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
PML_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
_LOCK_ROW_RE = re.compile(r"^-\s+([A-Za-z0-9_]+)\s*:\s*(.+?)\s*$")
_SVG_FONT_SIZE_RE = re.compile(r"^([0-9]+(?:\.[0-9]+)?)(?:px)?$")
_CJK_THEME_SCRIPTS = frozenset({"Hans", "Hant", "Jpan", "Hang"})
_TITLE_PLACEHOLDER_TYPES = frozenset({"title", "subtitle"})
_BODY_PLACEHOLDER_TYPES = frozenset({
    "body",
    "date",
    "footer",
    "slide-number",
})
_DEFAULT_MASTER_TITLE_PX = 40.0
_DEFAULT_MASTER_BODY_PX = 24.0


class ThemeFontError(RuntimeError):
    """Raised when a project theme-font contract cannot be loaded or applied."""


@dataclass(frozen=True)
class ThemeFontFace:
    """Concrete Latin, East Asian, and complex-script theme faces."""

    latin: str
    ea: str
    cs: str

    def matches(self, fonts: dict[str, str]) -> bool:
        """Return whether resolved SVG fonts represent this theme face."""
        return fonts.get("latin") == self.latin and fonts.get("ea") == self.ea


@dataclass(frozen=True)
class ThemeFontSpec:
    """Major/minor theme fonts derived from one project's typography lock."""

    major: ThemeFontFace
    minor: ThemeFontFace
    major_family: str
    minor_family: str
    # Supplemental theme scripts (``Arab``, ``Hebr``, ``Thai``, ``Deva``, ...)
    # the deck's primary language writes in; they take the locked
    # complex-script face instead of the Office factory default.
    cs_scripts: tuple[str, ...] = ()


@dataclass(frozen=True)
class MasterTextStyleSpec:
    """Title/body defaults written to one generated slide master's txStyles."""

    title_hpt: int
    body_hpt: int

    @property
    def body_levels_hpt(self) -> tuple[int, ...]:
        """Return a deterministic nine-level PowerPoint body-size hierarchy."""
        factors = (16, 15, 14, 13, 12, 11, 10, 9, 8)
        minimum = min(self.body_hpt, 800)
        sizes = []
        for factor in factors:
            scaled = round((self.body_hpt * factor / 16) / 50) * 50
            sizes.append(max(minimum, scaled))
        return tuple(sizes)


def _inline_style_property(style: str, name: str) -> str | None:
    """Return one inline SVG style declaration value."""
    for declaration in style.split(";"):
        key, separator, value = declaration.partition(":")
        if separator and key.strip().lower() == name:
            return value.strip()
    return None


def _svg_font_size_px(element: ET.Element) -> float | None:
    """Read one finite positive SVG font size in px."""
    raw = element.get("font-size")
    if raw is None:
        raw = _inline_style_property(element.get("style", ""), "font-size")
    if raw is None:
        return None
    match = _SVG_FONT_SIZE_RE.fullmatch(raw.strip())
    if match is None:
        return None
    value = float(match.group(1))
    return value if math.isfinite(value) and value > 0 else None


def infer_master_text_style_spec(
    svg_files: list[Path],
) -> tuple[MasterTextStyleSpec, float, float]:
    """Infer structured Master title/body defaults from SVG slot carriers."""
    title_sizes: list[float] = []
    body_sizes: list[float] = []
    placeholder_types = _TITLE_PLACEHOLDER_TYPES | _BODY_PLACEHOLDER_TYPES
    for svg_path in svg_files:
        try:
            root = ET.parse(svg_path).getroot()
        except (OSError, ET.ParseError) as exc:
            raise ThemeFontError(
                f"Cannot infer Master text defaults from {svg_path}: {exc}"
            ) from exc
        for slot in root.iter():
            placeholder = slot.get("data-pptx-placeholder")
            if placeholder not in placeholder_types:
                continue
            target = (
                title_sizes
                if placeholder in _TITLE_PLACEHOLDER_TYPES
                else body_sizes
            )
            for carrier in slot.iter():
                if carrier.get("data-pptx-carrier") != "true":
                    continue
                size = _svg_font_size_px(carrier)
                if size is not None:
                    target.append(size)

    title_px = (
        float(statistics.median(title_sizes))
        if title_sizes
        else _DEFAULT_MASTER_TITLE_PX
    )
    body_px = (
        float(statistics.median(body_sizes))
        if body_sizes
        else _DEFAULT_MASTER_BODY_PX
    )
    return (
        MasterTextStyleSpec(
            title_hpt=font_px_to_hpt(title_px),
            body_hpt=font_px_to_hpt(body_px),
        ),
        title_px,
        body_px,
    )


def _font_face(font_family: str, language: str | None = None) -> ThemeFontFace:
    fonts = parse_font_family(font_family, language)
    return ThemeFontFace(
        latin=fonts["latin"],
        ea=fonts["ea"],
        cs=fonts["latin"],
    )


def _typography_rows(lock_path: Path) -> dict[str, str]:
    rows: dict[str, str] = {}
    current_section: str | None = None
    try:
        lines = lock_path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ThemeFontError(f"Cannot read {lock_path}: {exc}") from exc

    for raw_line in lines:
        line = raw_line.strip()
        if line.startswith("## "):
            current_section = line[3:].strip()
            continue
        if current_section != "typography":
            continue
        match = _LOCK_ROW_RE.fullmatch(line)
        if match:
            rows[match.group(1)] = match.group(2)
    return rows


def load_theme_font_spec(
    project_path: Path,
    language: str | None = None,
) -> ThemeFontSpec | None:
    """Load major/minor theme fonts from ``spec_lock.md`` typography rows."""
    lock_path = project_path / "spec_lock.md"
    if not lock_path.is_file():
        return None
    rows = _typography_rows(lock_path)
    default_family = rows.get("font_family")
    major_family = rows.get("title_family") or default_family
    minor_family = rows.get("body_family") or default_family
    if not major_family or not minor_family:
        return None
    return ThemeFontSpec(
        major=_font_face(major_family, language),
        minor=_font_face(minor_family, language),
        major_family=major_family,
        minor_family=minor_family,
        cs_scripts=_complex_theme_scripts(language),
    )


def load_theme_font_spec_from_pages(
    project_path: Path,
    language: str | None = None,
) -> ThemeFontSpec | None:
    """Derive major/minor theme fonts from the first svg_output page.

    The page root's ``font-family`` is the minor (body) face; the family of
    the largest text on the page is the major (title) face.
    """
    pages = sorted((project_path / "svg_output").glob("*.svg"))
    if not pages:
        return None
    try:
        root = ET.parse(str(pages[0])).getroot()
    except ET.ParseError:
        return None
    minor_family = root.get("font-family") or _inline_style_property(
        root.get("style", ""), "font-family"
    )
    major_family = None
    largest = -1.0
    for element in root.iter():
        if not isinstance(element.tag, str) or element.tag.split("}")[-1] != "text":
            continue
        size = _svg_font_size_px(element)
        family = element.get("font-family") or _inline_style_property(
            element.get("style", ""), "font-family"
        )
        if not minor_family and family:
            minor_family = family
        if size is not None and size > largest and family:
            largest, major_family = size, family
    minor_family = minor_family or major_family
    major_family = major_family or minor_family
    if not major_family or not minor_family:
        return None
    return ThemeFontSpec(
        major=_font_face(major_family, language),
        minor=_font_face(minor_family, language),
        major_family=major_family,
        minor_family=minor_family,
        cs_scripts=_complex_theme_scripts(language),
    )


def _font_size_hpt(raw: str, field: str) -> int:
    try:
        px = float(raw)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ThemeFontError(
            f"spec_lock.md typography {field} must be a numeric px value: {raw!r}"
        ) from exc
    try:
        size = font_px_to_hpt(px)
    except ValueError as exc:
        raise ThemeFontError(
            f"spec_lock.md typography {field} is outside the PowerPoint "
            f"font-size range: {raw!r}"
        ) from exc
    return size


def load_master_text_style_spec(project_path: Path) -> MasterTextStyleSpec:
    """Load required title/body defaults for generated Master text styles."""
    lock_path = project_path / "spec_lock.md"
    if not lock_path.is_file():
        raise ThemeFontError(
            "Master export requires spec_lock.md typography title and body rows"
        )
    rows = _typography_rows(lock_path)
    missing = [field for field in ("title", "body") if field not in rows]
    if missing:
        raise ThemeFontError(
            "Master export requires spec_lock.md typography rows: "
            + ", ".join(missing)
        )
    return MasterTextStyleSpec(
        title_hpt=_font_size_hpt(rows["title"], "title"),
        body_hpt=_font_size_hpt(rows["body"], "body"),
    )


def theme_font_tokens(
    fonts: dict[str, str],
    spec: ThemeFontSpec | None,
) -> dict[str, str] | None:
    """Return DrawingML major/minor tokens for a locked SVG font face."""
    if spec is None:
        return None
    major_match = spec.major.matches(fonts)
    minor_match = spec.minor.matches(fonts)
    if major_match and not minor_match:
        prefix = "+mj"
    elif minor_match:
        # When title/body use the same family, minor is the least surprising
        # default for ordinary text boxes. Template assembly forces semantic
        # title placeholders to the major role after SVG conversion.
        prefix = "+mn"
    else:
        return None
    return {
        "latin": f"{prefix}-lt",
        "ea": f"{prefix}-ea",
        "cs": f"{prefix}-cs",
    }


# Theme ``<a:font script="...">`` codes by language base for scripts that
# PowerPoint renders through the complex-script slot.
_COMPLEX_SCRIPT_BY_LANGUAGE = {
    "he": "Hebr", "yi": "Hebr",
    "th": "Thai", "lo": "Laoo", "km": "Khmr", "my": "Mymr", "bo": "Tibt",
    "hi": "Deva", "mr": "Deva", "ne": "Deva", "sa": "Deva", "kok": "Deva",
    "bn": "Beng", "as": "Beng", "pa": "Guru", "gu": "Gujr", "or": "Orya",
    "ta": "Taml", "te": "Telu", "kn": "Knda", "ml": "Mlym", "si": "Sinh",
    "ka": "Geor", "hy": "Armn", "am": "Ethi", "ti": "Ethi",
}


def _complex_theme_scripts(language: str | None) -> tuple[str, ...]:
    """Return the theme supplemental script(s) the primary language writes in."""
    if not language:
        return ()
    script = _explicit_language_script(language)
    if script:
        return (script,)
    base = language_base(language)
    if base in _COMPLEX_SCRIPT_BY_LANGUAGE:
        return (_COMPLEX_SCRIPT_BY_LANGUAGE[base],)
    return ("Arab",) if language_uses_rtl(language) else ()


def _patch_font_collection(
    collection: ET.Element,
    face: ThemeFontFace,
    cs_scripts: tuple[str, ...] = (),
) -> None:
    for tag, value in (("latin", face.latin), ("ea", face.ea), ("cs", face.cs)):
        elem = collection.find(f"{{{DML_NS}}}{tag}")
        if elem is None:
            elem = ET.SubElement(collection, f"{{{DML_NS}}}{tag}")
        elem.set("typeface", value)
    for supplemental in collection.findall(f"{{{DML_NS}}}font"):
        if supplemental.get("script") in _CJK_THEME_SCRIPTS:
            supplemental.set("typeface", face.ea)
        elif supplemental.get("script") in cs_scripts:
            supplemental.set("typeface", face.cs)


def apply_theme_font_spec(extract_dir: Path, spec: ThemeFontSpec) -> None:
    """Install locked major/minor fonts into every existing PPTX theme part."""
    theme_dir = extract_dir / "ppt" / "theme"
    theme_paths = sorted(theme_dir.glob("theme*.xml"))
    if not theme_paths:
        raise ThemeFontError(f"PPTX package has no theme part under {theme_dir}")

    ET.register_namespace("a", DML_NS)
    for theme_path in theme_paths:
        try:
            tree = ET.parse(theme_path)
        except (OSError, ET.ParseError) as exc:
            raise ThemeFontError(f"Cannot parse {theme_path}: {exc}") from exc
        font_scheme = tree.getroot().find(f".//{{{DML_NS}}}fontScheme")
        if font_scheme is None:
            raise ThemeFontError(f"Theme has no fontScheme: {theme_path}")
        major = font_scheme.find(f"{{{DML_NS}}}majorFont")
        minor = font_scheme.find(f"{{{DML_NS}}}minorFont")
        if major is None or minor is None:
            raise ThemeFontError(f"Theme has no major/minor font collection: {theme_path}")
        font_scheme.set("name", "PPT Master")
        _patch_font_collection(major, spec.major, spec.cs_scripts)
        _patch_font_collection(minor, spec.minor, spec.cs_scripts)
        tree.write(theme_path, encoding="utf-8", xml_declaration=True)


def _style_run_properties(style: ET.Element, label: str) -> list[ET.Element]:
    run_properties = list(style.iter(f"{{{DML_NS}}}defRPr"))
    if not run_properties:
        raise ThemeFontError(f"slide master {label} has no a:defRPr entries")
    return run_properties


def _style_level_run_properties(
    style: ET.Element,
    label: str,
) -> tuple[ET.Element, ...]:
    """Return direct level 1-9 defaults from one Master text style."""
    levels: list[ET.Element] = []
    for level in range(1, 10):
        run_properties = style.find(
            f"{{{DML_NS}}}lvl{level}pPr/{{{DML_NS}}}defRPr"
        )
        if run_properties is None:
            raise ThemeFontError(
                f"slide master {label} has no level-{level} a:defRPr"
            )
        levels.append(run_properties)
    return tuple(levels)


def apply_master_text_style_spec(
    extract_dir: Path,
    spec: MasterTextStyleSpec,
) -> int:
    """Install declared title/body anchors into generated slide-master txStyles."""
    master_dir = extract_dir / "ppt" / "slideMasters"
    master_paths = sorted(master_dir.glob("slideMaster*.xml"))
    if not master_paths:
        raise ThemeFontError(f"PPTX package has no slide master under {master_dir}")

    ET.register_namespace("a", DML_NS)
    ET.register_namespace("p", PML_NS)
    for master_path in master_paths:
        try:
            tree = ET.parse(master_path)
        except (OSError, ET.ParseError) as exc:
            raise ThemeFontError(f"Cannot parse {master_path}: {exc}") from exc
        text_styles = tree.getroot().find(f"{{{PML_NS}}}txStyles")
        if text_styles is None:
            raise ThemeFontError(f"Slide master has no p:txStyles: {master_path}")

        title_style = text_styles.find(f"{{{PML_NS}}}titleStyle")
        if title_style is None:
            raise ThemeFontError(
                f"Slide master has no p:titleStyle: {master_path}"
            )
        for run_properties in _style_run_properties(
            title_style,
            "p:titleStyle",
        ):
            run_properties.set("sz", str(spec.title_hpt))

        body_levels = spec.body_levels_hpt
        for style_name in ("bodyStyle", "otherStyle"):
            style = text_styles.find(f"{{{PML_NS}}}{style_name}")
            if style is None:
                raise ThemeFontError(
                    f"Slide master has no p:{style_name}: {master_path}"
                )
            for run_properties, size in zip(
                _style_level_run_properties(
                    style,
                    f"p:{style_name}",
                ),
                body_levels,
            ):
                run_properties.set("sz", str(size))

        style_sizes = (
            ("titleStyle", (spec.title_hpt,)),
            ("bodyStyle", body_levels),
            ("otherStyle", body_levels),
        )

        tree.write(master_path, encoding="utf-8", xml_declaration=True)

        try:
            read_back = ET.parse(master_path).getroot()
        except (OSError, ET.ParseError) as exc:
            raise ThemeFontError(
                f"Cannot read back slide master {master_path}: {exc}"
            ) from exc
        read_back_styles = read_back.find(f"{{{PML_NS}}}txStyles")
        if read_back_styles is None:
            raise ThemeFontError(
                f"Slide master lost p:txStyles after update: {master_path}"
            )
        for style_name, expected_sizes in style_sizes:
            style = read_back_styles.find(f"{{{PML_NS}}}{style_name}")
            if style is None:
                actual_sizes: tuple[str | None, ...] = ()
            elif style_name == "titleStyle":
                actual_sizes = tuple(
                    item.get("sz")
                    for item in _style_run_properties(
                        style,
                        f"p:{style_name}",
                    )
                )
            else:
                actual_sizes = tuple(
                    item.get("sz")
                    for item in _style_level_run_properties(
                        style,
                        f"p:{style_name}",
                    )
                )
            if actual_sizes != tuple(str(size) for size in expected_sizes):
                raise ThemeFontError(
                    f"Slide master p:{style_name} size read-back failed: "
                    f"{master_path}"
                )
    return len(master_paths)
